# Allow Fire On Wood

This mod allows players to place fire on wood. There's no config, that's just all it does.

![Screenshot](https://github.com/michalczemierowski/valheim-AllowFireOnWood/blob/master/screenshots/ss.png?raw=true "a title")